package com.qfedu.mybatis.mapper;

import com.qfedu.mybatis.pojo.Vehicle;

public interface VehicleMapper {

	Vehicle selectVehicleById(Integer id);
}
