package com.qfedu.mybatis.mapper;

import com.qfedu.mybatis.pojo.Author;

public interface AuthorMapper {

	Author selectAuthorById(Integer id);
}
