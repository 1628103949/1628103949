package com.qfedu.mybatisblog.mapper;

import com.qfedu.mybatisblog.vo.BlogCustom;

public interface BlogMapperCustom {

	BlogCustom selectBlogById(Integer id);
}
